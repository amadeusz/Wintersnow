module GenotypesHelper
end
