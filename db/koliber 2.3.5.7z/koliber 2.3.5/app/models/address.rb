require 'composite_primary_keys'
class Address < ActiveRecord::Base
	set_primary_keys :klucz
end
