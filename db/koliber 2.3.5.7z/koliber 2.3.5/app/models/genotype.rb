class Genotype < ActiveRecord::Base
end
