require 'test_helper'

class RssHelperTest < ActionView::TestCase
end
