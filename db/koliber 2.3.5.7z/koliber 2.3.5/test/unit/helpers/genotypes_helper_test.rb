require 'test_helper'

class GenotypesHelperTest < ActionView::TestCase
end
